<?php

return [
    'cms_module' => 'Cms Pages',
    'cms_menu' => 'Cms menu',
    'cms_pages' => 'Managment pages',
    'cms_templates' => 'Managment templates',
];